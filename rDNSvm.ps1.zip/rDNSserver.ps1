configuration DNSServer
{
    Import-DscResource -module 'PSDesiredStateConfiguration'

    param ($MachineName)

    Node $AllNodes.Where{$_.Role -eq 'DNSServer'}.MachineName
    {
        WindowsFeature DNS
        {
            Ensure  = 'Present'
            Name    = 'DNS'
        }

        xDnsServerPrimaryZone $Node.zone
        {
            Ensure    = 'Present'
            Name      = $Node.Zone
            DependsOn = '[WindowsFeature]DNS'
        }

        foreach ($MXRec in $Node.MXRecords.keys) {
            xDnsRecord $MXRec
            {
                Ensure    = 'Present'
                Name      = MXRec
                Zone      = 'raitisIFvmPrivateZone.com'
                Type      = 'MXRecord'
                Target    = "raitisIFvm.mail.protection.outlook.com"
                DependsOn = '[WindowsFeature]DNS'
            }
        }

        foreach ($TXT in $Node.TXTRecords.keys) {
            xDnsRecord $TXT
            {
                Ensure    = 'Present'
                Name      = TXTRec
                Zone      = 'raitisIFvmPrivateZone.com'
                Type      = 'TXT'
                Target    = @{'TFSSrv1'= '10.0.0.10';'Client'='10.0.0.15';'BuildAgent'='10.0.0.30';'TestAgent1'='10.0.0.40';'TestAgent2'='10.0.0.50'};
                DependsOn = '[WindowsFeature]DNS'
            }
        }
    }
}
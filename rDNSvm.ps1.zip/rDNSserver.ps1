Configuration DNSserver
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the DNS
   WindowsFeature InstallDNS
	{
    Ensure = 'Present'
    Name   = 'DNS'
	}
  }
} 